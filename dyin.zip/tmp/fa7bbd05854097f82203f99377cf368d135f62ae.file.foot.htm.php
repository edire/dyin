<?php /* Smarty version Smarty-3.0.8, created on 2014-01-12 23:46:11
         compiled from "D:\phpStudy\WWW\dyin/tpl\Index/foot.htm" */ ?>
<?php /*%%SmartyHeaderCode:2655052d2b8c328d090-35230284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa7bbd05854097f82203f99377cf368d135f62ae' => 
    array (
      0 => 'D:\\phpStudy\\WWW\\dyin/tpl\\Index/foot.htm',
      1 => 1389525232,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2655052d2b8c328d090-35230284',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
 <a href="#">帮助</a> | <a href="#">意见反馈</a> | <a href="#">Edire</a> | <a href="#">联系我们</a> |  Copyright©2014 | Edire 版权所有 