<?php /* Smarty version Smarty-3.0.8, created on 2014-01-12 23:46:11
         compiled from "D:\phpStudy\WWW\dyin/tpl\Index/left.htm" */ ?>
<?php /*%%SmartyHeaderCode:1173952d2b8c31121b1-03774210%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8caf04bbdf391be3e44ef851729df1c3a43922d6' => 
    array (
      0 => 'D:\\phpStudy\\WWW\\dyin/tpl\\Index/left.htm',
      1 => 1389533980,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1173952d2b8c31121b1-03774210',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <ul class="left_nav">
      <li class="left_nav_li"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main'),$_smarty_tpl);?>
" class="left_nav_a"><em class="home1 bs2"></em>Dyin首页</a></li>
      <li class="left_nav_li"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'mytake'),$_smarty_tpl);?>
" class="left_nav_a"><em class="chuandi bs2"></em>我传递的
		<!--<em class="news1"></em>--></a></li>
      <li class="left_nav_li"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'mymake'),$_smarty_tpl);?>
" class="left_nav_a"><em class="fabu bs2"></em>我发布的</a></li>
      <li class="left_nav_li"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'myinfo'),$_smarty_tpl);?>
" class="left_nav_a"><em class="shezhi bs2"></em>账户管理</a></li>
    </ul>